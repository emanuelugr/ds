package com.example.ej4_creador_personajes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
